# NavHide 2.0 – GUI + independent switches

This revision is based on the uploaded `hidenavbar-master.zip` source.

## Changes
- Added a launcher settings screen.
- Added independent switches for H3 IME dimension hook and H6 system-server Insets/config hooks.
- Settings are stored in the module app's private preferences and exposed to hooked processes through an exported read-only ContentProvider `content://com.hidenavbar.navhide.config`.
- Added Gboard, Sogou, Baidu and iFlytek package names to the Xposed scope list, while retaining the original Doubao and `system` scopes.
- Added GitHub Actions build workflow.

## Important behavior / safety
- Defaults are ON to preserve the original source's behavior.
- Turning a switch OFF makes the hook call `proceed()` and preserves the original method result. Hook registration itself remains installed until the target process restarts.
- H6 is global within `system_server` and can affect navigation bar behavior system-wide. Keep its switch OFF if you only want to change keyboard layout.
- This source has not been compiled or tested on a physical Moto G57 Power. Validate on a backup/test setup first.
- The original H6 implementation sets navigation bar Insets frames to height 0; it is not equivalent to only adjusting Gboard spacing and may affect gesture/navigation layout. The GUI does not silently change that original behavior.

## Build
Open Actions → Build NavHide → Run workflow. Download `NavHide-2.0-apks`.

## Install
Install APK, enable module in LSPosed, retain `system` scope only if you intend to use H6, and select the IME package(s) you use for H3. Open NavHide from the launcher to change switches.
