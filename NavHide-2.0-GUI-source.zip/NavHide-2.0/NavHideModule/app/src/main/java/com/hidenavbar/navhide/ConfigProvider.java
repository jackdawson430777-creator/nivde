package com.hidenavbar.navhide;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.content.Context;

public class ConfigProvider extends ContentProvider {
    public static final String AUTHORITY = "com.hidenavbar.navhide.config";
    public static final String PREFS = "navhide_settings";
    @Override public boolean onCreate() { return true; }
    @Override public Bundle call(String method, String arg, Bundle extras) {
        Context c = getContext();
        if (c == null) return Bundle.EMPTY;
        if ("get".equals(method)) {
            var p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            Bundle b = new Bundle();
            b.putBoolean("ime_enabled", p.getBoolean("ime_enabled", true));
            b.putBoolean("system_enabled", p.getBoolean("system_enabled", true));
            return b;
        }
        return Bundle.EMPTY;
    }
    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
