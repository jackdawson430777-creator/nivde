package com.hidenavbar.navhide;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(ConfigProvider.PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(246,247,251));
        getWindow().setNavigationBarColor(Color.rgb(246,247,251));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(246,247,251));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(30), dp(22), dp(28));
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("NavHide");
        title.setTextSize(29);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(25,32,48));
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("导航栏与输入法空间控制");
        subtitle.setTextSize(14);
        subtitle.setTextColor(Color.rgb(95,103,119));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.bottomMargin = dp(24);
        page.addView(subtitle, sp);

        addSwitchCard(page, "输入法底部空间修复", "H3 · 在已配置作用域的输入法进程中生效",
                "ime_enabled", true);
        addSwitchCard(page, "系统导航栏 Insets 修复", "H6 · 仅在 system_server 作用域中生效",
                "system_enabled", true);

        TextView note = new TextView(this);
        note.setText("修改开关后立即保存。Hook 会在下一次对应调用时读取设置；如需确保所有进程状态一致，可重启对应应用或设备。关闭系统导航栏修复可恢复原始 Insets 行为。");
        note.setTextSize(13);
        note.setTextColor(Color.rgb(92,100,115));
        note.setPadding(dp(4), dp(18), dp(4), 0);
        page.addView(note);

        TextView reset = new TextView(this);
        reset.setText("恢复默认设置");
        reset.setTextSize(14);
        reset.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        reset.setTextColor(Color.rgb(45,75,130));
        reset.setGravity(Gravity.CENTER);
        reset.setBackgroundColor(Color.WHITE);
        reset.setPadding(dp(12), dp(16), dp(12), dp(16));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(24);
        page.addView(reset, rp);
        reset.setOnClickListener(v -> {
            prefs.edit().putBoolean("ime_enabled", true).putBoolean("system_enabled", true).apply();
            recreate();
        });
        setContentView(scroll);
    }

    private void addSwitchCard(LinearLayout page, String heading, String detail, String key, boolean def) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(15), dp(14), dp(15));
        card.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(14);
        page.addView(card, cp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = new TextView(this);
        name.setText(heading);
        name.setTextSize(16);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setTextColor(Color.rgb(28,35,50));
        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        Switch sw = new Switch(this);
        sw.setChecked(prefs.getBoolean(key, def));
        row.addView(sw);
        card.addView(row);

        TextView desc = new TextView(this);
        desc.setText(detail);
        desc.setTextSize(12);
        desc.setTextColor(Color.rgb(105,112,126));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = dp(6);
        card.addView(desc, dp);
        sw.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean(key, checked).apply());
    }
}
